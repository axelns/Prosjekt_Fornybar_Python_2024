import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

"Effektberegning"
#   Lager en liste som beskriver hvor mye effekt som blir produsert i de forskjellige vindhastighetene
vref = np.arange(31)
Pref = np.array([0, 0, 0, 20, 50, 90, 165, 270, 360, 410, 540, 720, 760, 775, 780, 780, 780, 780, 780, 780, 780, 780, 780, 780, 780, 780, 0, 0, 0, 0, 0])
P_turbin, A_turbin, P_luft = 780, 2.27, 1.24                # Maks effekt, turbinareal, lufttetthet

#eta_v = (2 * Pref) / (P_luft * A_turbin * vref ** 3)        # Utregning av virkningsgrad

#   Lager en funksjon for å hente ut vindhastighet og tid, og fjerner vindhastighet over 25m/s
skip_last_lines = 1
def import_wind(filnavn):
    data = pd.read_csv(filnavn, delimiter=";",  decimal=',', parse_dates=['Tid(norsk normaltid)'], dayfirst=True, header=0).head(-skip_last_lines)
    tvec, Vvec = data['Tid(norsk normaltid)'].to_numpy(), data['Middelvind'].replace(',', '.').astype(float).to_numpy()
    Vvec[Vvec > 25] = 0
    return tvec, Vvec

#   Lager en funksjon for å hente ut vindhastighet og tid
def import_wind_M25(filnavn):
    data = pd.read_csv(filnavn, delimiter=";",  decimal=',', parse_dates=['Tid(norsk normaltid)'], dayfirst=True, header=0).head(-skip_last_lines)
    tvec, Vvec = data['Tid(norsk normaltid)'].to_numpy(), data['Middelvind'].replace(',', '.').astype(float).to_numpy()
    return tvec, Vvec

#   Henter ut 8760 verdier fra vinddata-filene for Lyngdal og Harstad
tvec_L, Vvec_L = import_wind('Vind_Lyngdal.csv')
tvec_H, Vvec_H = import_wind('Vind_Harstad.csv')
tvec_L_M25, Vvec_L_M25 = import_wind_M25('Vind_Lyngdal.csv')
tvec_H_M25, Vvec_H_M25 = import_wind_M25('Vind_Harstad.csv')

#   Kombinerer vinddata, tidsdata og effekten per vindhastighet, Får ut effekten turbinen produserer per time i kWh
def interpolate_array(array1, target_length):
    # Generate indices for the interpolated points
    interpolated_indices = np.linspace(0, len(array1) - 1, target_length - len(array1), dtype=int)

    # Interpolate values for the new points using linear interpolation
    interpolated_values = np.interp(interpolated_indices, np.arange(len(array1)), array1)

    # Insert the interpolated values into array1
    interpolated_array = array1.copy()
    for index, value in zip(interpolated_indices, interpolated_values):
        interpolated_array = np.insert(interpolated_array, index, value)

    return interpolated_array


def interpolate_datetime_array(array1, target_length):
    # Convert datetime values to timestamps (float64)
    timestamps = array1.astype(np.int64) // 10**9  # Convert nanoseconds to seconds

    # Generate indices for the interpolated points
    interpolated_indices = np.linspace(0, len(timestamps) - 1, target_length, dtype=int)

    # Interpolate timestamps
    interpolated_timestamps = np.interp(interpolated_indices, np.arange(len(timestamps)), timestamps)

    # Convert interpolated timestamps back to datetime values
    interpolated_datetime = pd.to_datetime(interpolated_timestamps, unit='s')

    return interpolated_datetime

tvec_Interp_L = interpolate_datetime_array(tvec_L, 8760)
Vvec_Interp_L = interpolate_array(Vvec_L, 8760)

tvec_Interp_H = interpolate_datetime_array(tvec_H, 8760)
Vvec_Interp_H = interpolate_array(Vvec_H, 8760)


Pvind_L = np.interp(Vvec_Interp_L, vref, Pref) / 1000
Pvind_H = np.interp(Vvec_H, vref, Pref) / 1000
Pvind_L_M25 = np.interp(Vvec_L_M25, vref, Pref) / 1000
Pvind_H_M25 = np.interp(Vvec_H_M25, vref, Pref) / 1000
np.save('Lyngdal_EprodVind.npy', Pvind_L)
np.save('Harstad_Eprodvind.npy', Pvind_H)
print("=============", len(Pvind_L))
#   Total effekt i Harstad og Lyngdal i kWh
Ptot_L, Ptot_H = np.sum(Pvind_L), np.sum(Pvind_H)     


#   Lager en funksjon for å få ut verdiene per måned, altså 12 punkter istedenfor 8760
def monthly_avg(tvec, Vvec):
    df = pd.DataFrame({'timestamp': tvec, 'Wind-power': Vvec})
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    monthly_avg = df.groupby(pd.Grouper(key='timestamp', freq='M'))['Wind-power'].mean().reset_index()
    monthly_avg.columns = ['Month', 'Monthly Average Wind']
    return monthly_avg

monthly_avg_L, monthly_avg_H = monthly_avg(tvec_L, Vvec_L), monthly_avg(tvec_H, Vvec_H)

#   Lager en funksjon for å produsere en søylegraf for effekten turbiner produserer per måned
def plot_monthly_WP(data_list, title_list, overhead, colors=None):
    if colors is None:
        colors = ['blue', 'green', 'red', 'purple', 'orange']
    fig, ax = plt.subplots(1, 1)
    for i, (data, title) in enumerate(zip(data_list, title_list)):
        grupper = [data[j:j + 730] for j in range(0, len(data), 730)]
        summer_per_måned = [sum(gruppe) for gruppe in grupper]
        month = ['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Des']
        ax.bar(month, summer_per_måned, color=colors[i], label=title)
    ax.set(xlabel='Måned', ylabel='Effekt [kWh]', title=overhead)
    ax.legend()
    plt.show()

#   Setter inn effektverdiene fra Harstad og Lyngdal inn i funksjonen over
plot_monthly_WP([Pvind_L, Pvind_H], ['Lyngdal', 'Harstad'], 'Monthly Wind Power', ['g', 'r'])

#   Lager en funksjon for å produsere en linjegraf for vindhastighet per måned
måneder = ['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Des']
def plot_data(data, ylabel, title):
    fig, ax = plt.subplots(1,1)
    for i, dataset in enumerate(data, start=1):
        data_per_month = [np.sum(np.array_split(dataset, 12)[j]) for j in range(12)]
        label_text = 'Harstad' if i == 1 else 'Lyngdal' 
        ax.plot(måneder, data_per_month, label=label_text)

    ax.set_xlabel('Måneder')
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()

#   Setter inn gjennomsnittlig vindhastighet fra Harstad og Lyngdal inn i funksjonen over
plot_data([monthly_avg_H['Monthly Average Wind'].tolist(), monthly_avg_L['Monthly Average Wind'].tolist()], 
          'Månedlig gjennomsnittsvind', 
          'Månedlig vindsammenligning')





























# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt



# "Effektberegning"
# vref = np.arange(31)
# Pref = np.array([0, 0, 0, 20, 50, 90, 165, 270, 360, 410, 540, 720, 760, 775, 780, 780, 780, 780, 780, 780, 780, 780, 780, 780, 780, 780, 0, 0, 0, 0, 0])

# P_turbin = 780      #W
# A_turbin = 2.27     #m2
# P_luft = 1.24       #kg/m3

# eta_v = (2 * Pref) / (P_luft * A_turbin * vref ** 3)


# skip_last_lines = 1

# def import_wind(filnavn):
    

#     data = pd.read_csv(filnavn, delimiter=";",  decimal=',', parse_dates=['Tid(norsk normaltid)'], dayfirst=True, header=0)
#     data = data.head(-skip_last_lines)
#     tvec = data['Tid(norsk normaltid)'].to_numpy()
#     Vvec = data['Middelvind'].replace(',', '.').astype(float).to_numpy()

#     Vvec[Vvec > 25] = 0

#     return tvec, Vvec

# def import_wind_M25(filnavn):
    

#     data = pd.read_csv(filnavn, delimiter=";",  decimal=',', parse_dates=['Tid(norsk normaltid)'], dayfirst=True, header=0)
#     data = data.head(-skip_last_lines)
#     tvec = data['Tid(norsk normaltid)'].to_numpy()
#     Vvec = data['Middelvind'].replace(',', '.').astype(float).to_numpy()

    
#     return tvec, Vvec

# ############ Vvec[Vvec > 25] = np.nan



# tvec_L, Vvec_L = import_wind('Vind_Lyngdal.csv')
# tvec_H, Vvec_H = import_wind('Vind_Harstad.csv')

# tvec_L_M25, Vvec_L_M25 = import_wind_M25('Vind_Lyngdal.csv')
# tvec_H_M25, Vvec_H_M25 = import_wind_M25('Vind_Harstad.csv')

# # print(Vvec_L)

# # print(len(tvec_L), len(Vvec_L))
# # print(len(tvec_H), len(Vvec_H))




# Pvind_L = np.interp(Vvec_L, vref, Pref) / 1000
# Pvind_H = np.interp(Vvec_H, vref, Pref) / 1000

# Pvind_L_M25 = np.interp(Vvec_L_M25, vref, Pref) / 1000
# Pvind_H_M25 = np.interp(Vvec_H_M25, vref, Pref) / 1000


# np.save('Lyngdal_EprodVind.npy', Pvind_L)
# np.save('Harstad_Eprodvind.npy', Pvind_H)

# np.save('Lyngdal_EprodVind_M25.npy', Pvind_L_M25)
# np.save('Harstad_Eprodvind_M25.npy', Pvind_H_M25)

# # for i in range(Pvind_L):
    
# #     print(f'PVind_L = {np.sum(Pvind_L)}')

# Ptot_L = np.sum(Pvind_L_M25)
# Ptot_H = np.sum(Pvind_H_M25) # kWh/year

# print(f'Ptot Lyng = {Ptot_L}', f'Ptot Hars = {Ptot_H}')
# # Assuming your dataset is already loaded into a DataFrame called df with a 'timestamp' column and a 'wind_power' column

# # Convert the 'timestamp' column to datetime if it's not already in datetime format

# def daily_avg(tvec, Vvec):
#     df = pd.DataFrame({'timestamp' : tvec, 'Wind-power' : Vvec})
#     df['timestamp'] = pd.to_datetime(df['timestamp'])
#     daily_avg = df.groupby(df['timestamp'].dt.date)['Wind-power'].mean()
#     daily_avg = daily_avg.reset_index()
#     daily_avg.columns = ['Date', 'Daily Average Wind']
#     return daily_avg



# def weekly_avg(tvec, Vvec):
#     df = pd.DataFrame({'timestamp': tvec, 'Wind-power': Vvec})
#     df['timestamp'] = pd.to_datetime(df['timestamp'])
#     weekly_avg = df.groupby(pd.Grouper(key='timestamp', freq='W'))['Wind-power'].mean()
#     weekly_avg = weekly_avg.reset_index()
#     weekly_avg.columns = ['Week', 'Weekly Average Wind']
#     return weekly_avg



# def monthly_avg(tvec, Vvec):
#     df = pd.DataFrame({'timestamp': tvec, 'Wind-power': Vvec})
#     df['timestamp'] = pd.to_datetime(df['timestamp'])
#     monthly_avg = df.groupby(pd.Grouper(key='timestamp', freq='M'))['Wind-power'].mean()
#     monthly_avg = monthly_avg.reset_index()
#     monthly_avg.columns = ['Month', 'Monthly Average Wind']
#     return monthly_avg




# daily_avg_L = daily_avg(tvec_L, Vvec_L)
# daily_avg_H = daily_avg(tvec_H, Vvec_H)

# weekly_avg_L = weekly_avg(tvec_L, Vvec_L)
# weekly_avg_H = weekly_avg(tvec_H, Vvec_H)

# monthly_avg_L = monthly_avg(tvec_L, Vvec_L)
# monthly_avg_H = monthly_avg(tvec_H, Vvec_H)

# # Rename the columns if needed
# # daily_averages.columns = ['Date', 'Daily_Average_Wind_Power']



# "Plotting effektkurve"
    
# def plot_monthly_WP(data_list, title_list, overhead, colors=None):
#     if colors is None:
#         colors = ['blue', 'green', 'red', 'purple', 'orange']  # Add more colors if needed

#     fig, ax = plt.subplots(1, 1)
    
#     for i, (data, title) in enumerate(zip(data_list, title_list)):
#         grupper = [data[j:j + 730] for j in range(0, len(data), 730)]
#         summer_per_måned = [sum(gruppe) for gruppe in grupper]

#         month = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

#         ax.bar(month, summer_per_måned, color=colors[i], label=title)

#     ax.set(xlabel='Måned', ylabel='Effekt [kW]')
#     ax.set_title(overhead)
#     ax.legend()
#     plt.show()


# plot_monthly_WP([Pvind_L, Pvind_H], ['Lyngdal', 'Harstad'], 'Monthly Wind Power', ['g', 'r'])
















def plot_wind(tvec, Vvec, label='', color='blue'):
    fig, ax = plt.subplots(1, 1)
    ax.plot(tvec, Vvec, label=label, color=color)
    ax.set_xlabel('Tid')
    ax.set_ylabel('Wind [m/s]')
    ax.set_title('Wind 2023')
    ax.legend()
    plt.show()


def plot_wind_comparison(tvec1, Vvec1, label1='', color1='blue', tvec2=None, Vvec2=None, label2='', color2='red'):
    fig, ax = plt.subplots(1, 1)
    ax.plot(tvec1, Vvec1, label=label1, color=color1)
    if tvec2 is not None and Vvec2 is not None:
        ax.plot(tvec2, Vvec2, label=label2, color=color2)
    ax.set_xlabel('Tid')
    ax.set_ylabel('Wind [m/s]')
    ax.set_title('Wind Comparison')
    ax.legend()
    plt.show()



# def plot_monthly_WP(data_list, title_list, overhead, colors='blue'):
#     if colors is None:
#         colors = ['blue', 'green', 'red', 'purple', 'orange']  # Add more colors if needed

#     fig, ax = plt.subplots(1, 1)
    
#     for i, data in enumerate(data_list):
#         grupper = [data[j:j + 730] for j in range(0, len(data), 730)]
#         summer_per_måned = [sum(gruppe) for gruppe in grupper]

#         month = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

#         ax.bar(month, summer_per_måned, color=colors[i], label=title_list[i])

#     ax.set(xlabel='Måned', ylabel='Effekt [kW]')
#     ax.set_title(overhead)
#     ax.legend()
#     plt.show()

# plot_monthly_WP([Pvind_L], 'Lyngdal', 'g')
# plot_monthly_WP([Pvind_H], 'Harstad', 'r')



def plot_comparison_chart():
    fig, ax = plt.subplots(1, 1)
    ax.plot(tvec_L, Pvind_L, label='Lyngdal', color='green')
    ax.plot(tvec_H, Pvind_H, label='Harstad', color='red')
    ax.set_xlabel('Tid')
    ax.set_ylabel('Temp [C]')
    ax.set_title('Temperatur 2023')
    ax.legend()
    plt.show()



# plot_wind_comparison(daily_avg_H['Date'], daily_avg_H['Daily Average Wind'], label1='Harstad', color1='r', 
#                      tvec2=daily_avg_L['Date'], Vvec2=daily_avg_L['Daily Average Wind'], label2='Lyngdal', color2='g')

# plot_wind_comparison(weekly_avg_H['Week'], weekly_avg_H['Weekly Average Wind'], label1='Harstad', color1='r', 
#                      tvec2=weekly_avg_L['Week'], Vvec2=weekly_avg_L['Weekly Average Wind'], label2='Lyngdal', color2='g')


plot_wind_comparison(tvec1=monthly_avg_H['Month'], Vvec1=monthly_avg_H['Monthly Average Wind'], 
                     tvec2=monthly_avg_L['Month'], Vvec2=monthly_avg_L['Monthly Average Wind'], 
                     label1='Harstad Monthly', label2='Lyngdal Monthly', 
                     color1='r', color2='g')


# plot_wind(daily_avg_H['Date'], daily_avg_H['Daily Average Wind'], label='Harstad', color='r')
# plot_wind(daily_avg_L['Date'], daily_avg_L['Daily Average Wind'], label='Lyngdal', color='g')

# plot_wind(weekly_avg_H['Week'], weekly_avg_H['Weekly Average Wind'], label='Harstad', color='r')
# plot_wind(weekly_avg_L['Week'], weekly_avg_L['Weekly Average Wind'], label='Lyngdal', color='g')


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


" Importering av utetemperatur"

# Sjekk lastet ned data:  brukes koma eller punktum   

"Data for beregningen"
# Dimensjoner rom
R1_L  = 9;          # Lengde, rom 1 (m)
R1_B  = 5.4;        # Bredde, rom 1 (m)
R2_L  = 6;          # Lengde, rom 2 (m)
R2_B  = 4.2;        # Bredde, rom 2 (m)
R3_L  = 3;          # Lengde, rom 3 (m)
R3_B  = 4.2;        # Bredde, rom 3 (m)
RH    = 3;          # Etasjehøyde (m)
A_tot = R1_L * (R2_L + R1_B)

"Dimensjoner på¸rer og vinduer"
dor_B       = 1;          # Bredde, innerdører/ytterdør (m)
dor_H       = 2;          # Høyde, innerdører/ytterdør (m)
vindu_B     = 0.15;       # Bredde, vindu (m)
vindu_H     = 0.25;       # Høyde, vindu (m)

" Dimensjoner veggkonstruksjonen"
x_gips          = 0.0125;                   # Tykkelse, gipsplate (m)
x_stn           = 0.148;                    # Tykkelse, stendere (m)
x_ull           = 0.148;                    # Tykkelse, mineralull (m)
x_teglstein     = 0.1;                      # Tykkelse, teglstein (m)
x_cc            = 0.6;                      # Senteravstand, stendere (m)
x_B_stn         = 0.036;                    # Bredde, stendere (m)
x_B_ull         = x_cc - x_B_stn;           # Bredde, isolasjon (m)
x_yttervegg     = x_gips + x_ull + x_teglstein
x_fakk          = 0.148                     # Tykkelse, yttervegg, uten gips og tegl

"Parametre for varmeegenskaper"
R_i             = 0.13;                     # Overgangsresistans, innervegg (m2*K/W)
R_u             = 0.04;                     # Overgangsresistans, yttervegg (m2*K/W)
R_tak           = 2;                        # Varmeresistans, loft og tak (m2*K/W)
R_gulv          = 3;                        # Varmeresistans, gulv mot utsiden (m2*K/W)
k_gips          = 0.2;                      # Varmekonduktivitet, gipsplate (W/m/K)
k_stn           = 0.120;                    # Varmekonduktivitet, stendere (W/m/K)
k_ull           = 0.034;                    # Varmekonduktivitet, mineralull (W/m/K)
k_teglstein 	= 0.8;                      # Varmekonduktivitet, teglstein (W/m/K)
U_kjolevegg     = 0.15;                     # U-verdi, kjøleromsvegg (W/m2/K)
U_kjoledor      = 0.3;                      # U-verdi, kjøleromsdør (W/m2/K)
U_utedor        = 0.2;                      # U-verdi, utedør (W/m2/K)
U_innervegg     = 1;                        # U-verdi, innervegg (W/m2/K)
U_vindu         = 0.8;                      # U-verdi, vinduer (W/m2/K)

"Parametre for luft"
T_o              = 20;            # Temperatur, oppholdsrom (C)
T_k              = 4;             # Temperatur, kjølerom (C)
luft_rho         = 1.24;          # Tetthet, luft (kg/m3)
luft_c           = 1;             # Varmekapasitet, luft (kJ/kg/K)



" Parametre for ventilasjon og infiltrasjon "
S1_infiltrasjon =   0.4;                      # Luftskifte, infiltrasjon sone 1 (1/h)
S2_infiltrasjon =   0.2;                      # Luftskifte, infiltrasjon sone 2 (1/h)
S1_ventilasjon  =   0.6;                      # Luftskifte, ventilasjon sone 1 (1/h)
S2_ventilasjon  =   0;                        # Luftskifte, ventilasjon sone 2 (1/h)
eta_vv          =   0.8;                      # Virkningsgrad, varmeveksler   

" Parametre for teknologi for oppvarming og nedkøling "
eta_el          = 1;     # Virkningsgrad, direkte elektrisk oppvarming
COP_hp          = 4;     # COP-faktor varmepumpe hele året
COP_kj          = 3;     # COP-faktor kjølemaskin hele året

" BEREGNE AREAL vinduer"
vindu_Arute     = vindu_B*vindu_H;
vindu_Arute4    = 4*vindu_Arute;
vindu_Arute8    = 8*vindu_Arute;
S1_A_vindu       = 5*vindu_Arute8 + 2*vindu_Arute4;
S2_A_vindu       = 2*vindu_Arute8 + 0*vindu_Arute4;

" BEREGNE AREAL dører"
dor_A         = dor_H*dor_B;
S1_A_dor      = 1*dor_A;
S2_A_dor      = 0*dor_A;
S1_S2_A_dor   = 1*dor_A;

" BEREGNE AREAL veggflater inkludert dører/vinduer "
S1_A_yttervegg = (R1_B + R1_L + R1_B + R2_B + R2_L)*RH;
S2_A_yttervegg = (R3_B + R3_L)*RH;
S1_S2_A_vegg   = (R3_B + R3_L)*RH;
# print(S1_A_yttervegg)
# print(S2_A_yttervegg)
# print(S1_S2_A_vegg)

# print(f' S1 = {U_ut_S1_eks_S2}')
# print(f' S2 = {U_ut_S2_eks_S1}')
# print(f' S1_S2 = {U_S1_S2}')

" Grensesjikt mellom temperatursoner ekskludert dÃ¸rer/vinduer "
S1_Atot_yttervegg  = S1_A_yttervegg - S1_A_vindu - S1_A_dor;
S2_Atot_yttervegg  = S2_A_yttervegg - S2_A_vindu - S2_A_dor;
S1_S2_Atot_vegg	   = S1_S2_A_vegg - S1_S2_A_dor;
S1_S2_Atot_yttervegg = S1_S2_A_vegg - S1_A_vindu - S1_A_dor - S2_A_vindu -S2_A_dor


" Gulvareal og takareal "
S1_A_gulv       = R1_B*R1_L + R2_B*R2_L;
S2_A_gulv       = R3_B*R3_L;
S1_A_tak        = S1_A_gulv;
S2_A_tak        = S2_A_gulv;
S1_A_Br         = S1_A_gulv; # Bruksareal
S2_A_Br         = S2_A_gulv; # Bruksareal

" Grensesjikt mellom temperatursoner inkludert dører/vinduer "
S1_Atot_ut      = S1_A_yttervegg + S1_A_tak + S1_A_gulv;
S2_Atot_ut      = S2_A_yttervegg + S2_A_tak + S2_A_gulv;
S1_S2_Atot_gs   = S1_S2_A_vegg;


" Beregne volum "
S1_V            = S1_A_Br*RH;
S2_V            = S2_A_Br*RH;



skip_last_lines = 1

def f_lufttemperatur_import_Tu(filnavn):
    data = pd.read_csv(filnavn, delimiter=";",  decimal=',', parse_dates=['Tid(norsk normaltid)'], dayfirst=True, header=0)
    data = data.head(-skip_last_lines)
    tvec = data['Tid(norsk normaltid)'].to_numpy()
    Tuvec = data['Lufttemperatur'].replace(',', '.').astype(float).to_numpy()
    return tvec, Tuvec

tvec_L, Tuvec_L = f_lufttemperatur_import_Tu('Temperatur_Lyngdal.csv')
tvec_H, Tuvec_H = f_lufttemperatur_import_Tu('Temperatur_Harstad.csv')

" U-verdimetoden"
R_gips = x_gips/k_gips
R_tegl = x_teglstein/k_teglstein

# 1 Beregne U-verdi for isolasjonsseksjonen
R_ull = x_ull/k_ull

R_tot_ull_S1 = R_i + R_u + R_ull + R_gips + R_tegl

U_tot_ull = 1/R_tot_ull_S1


# 2 Beregne U-verdi for stenderseksjonen
R_stn = x_stn/k_stn

R_tot_stn_S1 = R_i + R_u + R_stn + R_gips + R_tegl

U_tot_stn = 1/R_tot_stn_S1






# print(f'S2_Atot = {S2_Atot_yttervegg}')

# stn_tot = x_stn * Ant_fakk










# 3 Beregne U-verdi for yttervegg i sone 1 og 2 uten vinduer/dører

stnpro = x_B_stn/x_cc
ullpro = x_B_ull/x_cc

Ant_fakk_S1 = (R1_L + 2*R1_B + R2_L + R2_B)/x_cc
Ant_fakk_S2 = (R3_L + R3_B)/x_cc




A_tot_ull_S1 = Ant_fakk_S1 * ullpro
A_tot_ull_S2 = Ant_fakk_S2 * ullpro

A_tot_stn_S1 = (Ant_fakk_S1 + 1) * stnpro
A_tot_stn_S2 = (Ant_fakk_S2 + 1) * stnpro

U_U_met_S1 = ((A_tot_ull_S1/(A_tot_ull_S1 + A_tot_stn_S1)) * U_tot_ull) + (A_tot_stn_S1/(A_tot_stn_S1 + A_tot_ull_S1) * U_tot_stn)
U_U_met_S2 = ((A_tot_ull_S2/(A_tot_ull_S2 + A_tot_stn_S2)) * U_tot_ull) + (A_tot_stn_S2/(A_tot_stn_S2 + A_tot_ull_S2) * U_tot_stn)


# R_tot_S1 = R_i + R_u + (R_stn * stnpro) + (R_ull * ullpro) + R_gips + R_tegl
# print(f'Rtot = {R_tot_S1}')


" k-verdimetoden"

# 1 Beregne legert k-verdi for det inhomogene sjiktet
# print(x_B_ull)



k_fakk_S1 = (k_ull * ((A_tot_ull_S1)/(A_tot_ull_S1 + A_tot_stn_S1))) + (k_stn * ((A_tot_stn_S1)/(A_tot_ull_S1 + A_tot_stn_S1)))
k_fakk_S2 = (k_ull * ((A_tot_ull_S2)/(A_tot_ull_S2 + A_tot_stn_S2))) + (k_stn * ((A_tot_stn_S2)/(A_tot_ull_S2 + A_tot_stn_S2)))


# 2. Beregne U-verdi for yttervegg i sone 1 og 2 uten vinduer/dører

R_k_fakk_S1 = R_i + R_u + (x_fakk/k_fakk_S1) + R_gips + R_tegl
R_k_fakk_S2 = R_i + R_u + (x_fakk/k_fakk_S2) + R_gips + R_tegl
# print(f'R_k-met_fakk = {R_k_fakk_S2}')

U_k_met_S1 = 1/R_k_fakk_S1
U_k_met_S2 = 1/R_k_fakk_S2
# print(f'U-k-met_S1 = {U_k_met_S1}')

#       f'S1 = {round(U_U_met_S1, 4)} og S2 = {round(U_U_met_S2, 4)} \n'      #FUNKER
#       f'K-verdimetoden gir \n'                                              #FUNKER


" Gjennomsnitt av U-verdimetode og K-verdimetode"

Snitt_U_S1 = 1/2 * (U_k_met_S1 + U_U_met_S1)
Snitt_U_S2 = 1/2 * (U_k_met_S2 + U_U_met_S2)

# print(f'Gjennomsnitt av U-verdiene gir: \n'         #FUNKER
#       f'Sone 2 = {round(Snitt_U_S2, 4)}')           #FUNKER


" Beregne U-verdi for hele veggflatene"

U_vindu
S1_A_vindu
U_utedor
S1_A_dor
S1_A_yttervegg

# print(f'DørA = {S1_A_dor}')
# print(f'YtterveggA ink vinduer = {S1_A_yttervegg}')

U_tot_S1 = (Snitt_U_S1 * ((S1_Atot_yttervegg)/(S1_A_yttervegg))) + (U_vindu * ((S1_A_vindu)/(S1_A_yttervegg))) + (U_utedor * ((S1_A_dor)/(S1_A_yttervegg)))
U_tot_S2 = (Snitt_U_S2 * ((S2_Atot_yttervegg)/(S2_A_yttervegg))) + (U_vindu * ((S2_A_vindu)/(S2_A_yttervegg))) + (U_utedor * ((S2_A_dor)/(S2_A_yttervegg)))




" Beregne U-verdier for hele grensen mellom ulike soner:"
# print(f'Areal u/dør = {S1_S2_Atot_vegg} \n'
#       f'Areal dør = {S1_S2_A_dor} \n'
#       f'U kjølevegg = {U_kjolevegg} \n'

S1_A_gulv       = R1_B*R1_L + R2_B*R2_L;
S2_A_gulv       = R3_B*R3_L;
S1_A_tak        = S1_A_gulv;
S2_A_tak        = S2_A_gulv;
S1_A_Br         = S1_A_gulv; # Bruksareal
S2_A_Br         = S2_A_gulv; # Bruksareal

R_gulv
R_tak


# U-verdi mellom S1 og S2
U_S1_S2 = (U_kjolevegg * ((S1_S2_Atot_vegg)/(S1_S2_A_vegg))) + (U_kjoledor * ((S1_S2_A_dor)/S1_S2_A_vegg))




# U-verdi mellom S1 og Tak
U_tak = 1/R_tak
U_gulv = 1/R_gulv

U_tot_ut = ((U_tak * ((S1_A_Br)/(A_tot))) + (U_gulv * ((S1_A_gulv)/(A_tot))) + (U_tot_S1 * ((S1_Atot_yttervegg)/(A_tot))) + (U_tot_S2 * ((S2_Atot_yttervegg)/(A_tot))))



U_tot_S1
U_tot_S2
U_tak
U_gulv
A_tot_GTS1 = S1_A_yttervegg + S1_A_tak + S1_A_Br
A_tot_GTS2 = S2_A_yttervegg + S2_A_tak + S2_A_Br

U_ut_S1_eks_S2 = (U_tot_S1 * ((S1_A_yttervegg)/(A_tot_GTS1))) + (U_tak * ((S1_A_tak)/A_tot_GTS1)) + (U_gulv * ((S1_A_Br)/(A_tot_GTS1)))
U_ut_S2_eks_S1 = (U_tot_S2 * ((S2_A_yttervegg)/(A_tot_GTS2))) + (U_tak * ((S2_A_tak)/A_tot_GTS2)) + (U_gulv * ((S2_A_Br)/(A_tot_GTS2)))



"Termisk energibehov"
# 1 Regn ut termisk energibehov for the forskjellige rommene
 # call data import
# Generere matrix som i boka
 # Konduksjon

U_values = np.array([U_tot_S1, U_tot_S2, U_S1_S2])  #u-verdier 
A_values = np.array([S1_A_yttervegg,S2_A_yttervegg, S1_S2_Atot_vegg])  #areal

delta_T_L = np.column_stack([T_o - Tuvec_L, T_k - Tuvec_L, np.ones(len(Tuvec_L)) * (T_o - T_k)])  # temperaturforskjeller

delta_T_H = np.column_stack([T_o - Tuvec_H, T_k - Tuvec_H, np.ones(len(Tuvec_H)) * (T_o - T_k)])

#konduksjon:
Q_dot_konduksjon_L = U_values * A_values * delta_T_L

Q_dot_konduksjon_H = U_values * A_values * delta_T_H


total_Q_dot_L = np.sum(Q_dot_konduksjon_L, axis=1), #total varmetap for hver sone

total_Q_dot_H = np.sum(Q_dot_konduksjon_H, axis=1), #total varmetap for hver sone

# 2 Ventilasjon uten varmeveksler
Q_dot_ventilasjon_S1_L = luft_rho * luft_c * S1_ventilasjon * S1_V * delta_T_L[:,0] / 3.6 #w 
Q_dot_ventilasjon_S2_L = luft_rho * luft_c * S2_ventilasjon * S2_V * delta_T_L[:,1] / 3.6

Q_dot_ventilasjon_S1_H = luft_rho * luft_c * S1_ventilasjon * S1_V * delta_T_H[:,0] / 3.6 #w 
Q_dot_ventilasjon_S2_H = luft_rho * luft_c * S2_ventilasjon * S2_V * delta_T_H[:,1] / 3.6


# 3 Ventilasjon med varmeveksler
Q_dot_vent_m_vv_S1_L = Q_dot_ventilasjon_S1_L * (eta_vv)
Q_dot_vent_m_vv_S2_L = Q_dot_ventilasjon_S2_L * (eta_vv)

Q_dot_vent_m_vv_S1_H = Q_dot_ventilasjon_S1_H * (eta_vv)
Q_dot_vent_m_vv_S2_H = Q_dot_ventilasjon_S2_H * (eta_vv)

# 4 Infiltrasjon uten varmeveksler
Q_dot_infiltrasjon_S1_L = luft_rho * luft_c * S1_infiltrasjon * S1_V * delta_T_L[:,0] / 3.6 
Q_dot_infiltrasjon_S2_L = luft_rho * luft_c * S2_infiltrasjon * S2_V * delta_T_L[:,1] / 3.6 

Q_dot_infiltrasjon_S1_H = luft_rho * luft_c * S1_infiltrasjon * S1_V * delta_T_H[:,0] / 3.6 
Q_dot_infiltrasjon_S2_H = luft_rho * luft_c * S2_infiltrasjon * S2_V * delta_T_H[:,1] / 3.6 

# 5 Infiltrasjon med varmeveksler
Q_dot_infiltrasjon_m_vv_S1_L = Q_dot_infiltrasjon_S1_L * (eta_vv)
Q_dot_infiltrasjon_m_vv_S2_L = Q_dot_infiltrasjon_S2_L * (eta_vv)

Q_dot_infiltrasjon_m_vv_S1_H = Q_dot_infiltrasjon_S1_H * (eta_vv)
Q_dot_infiltrasjon_m_vv_S2_H = Q_dot_infiltrasjon_S2_H * (eta_vv)


"Totalt oppvarmings- og kjølebehov beregnet som netto oppvarmingsbehov"
# Regn ut netto totale oppvarmings- og kølebehov
# 5 Uten varmeveksler
oppvarmingsbehov_S1_L = (Q_dot_konduksjon_L[:,0] + Q_dot_konduksjon_L[:,2] + Q_dot_ventilasjon_S1_L + Q_dot_infiltrasjon_S1_L)
oppvarmingsbehov_S2_L = (Q_dot_konduksjon_L[:,1] - Q_dot_konduksjon_L[:,2] + Q_dot_ventilasjon_S2_L + Q_dot_infiltrasjon_S2_L)

oppvarmingsbehov_S1_H = (Q_dot_konduksjon_H[:,0] + Q_dot_konduksjon_H[:,2] + Q_dot_ventilasjon_S1_H + Q_dot_infiltrasjon_S1_H)
oppvarmingsbehov_S2_H = (Q_dot_konduksjon_H[:,1] - Q_dot_konduksjon_H[:,2] + Q_dot_ventilasjon_S2_H + Q_dot_infiltrasjon_S2_H)

# kanskje heller slik? for å få med delta_T fra s1 til s2. 
#oppvarmingsbehov_S1 = np.sum(Q_dot_konduksjon[:,0] + Q_dot_konduksjon[:,2] + Q_dot_ventilasjon_S1 + Q_dot_infiltrasjon_S1)
#oppvarmingsbehov_S2 = np.sum(Q_dot_konduksjon[:,1] - Q_dot_konduksjon[:,2] + Q_dot_ventilasjon_S2 + Q_dot_infiltrasjon_S2)

# 6 Med varmeveksler
oppvarmingsbehov_m_vv_S1_L = (Q_dot_konduksjon_L[:,0] + Q_dot_konduksjon_L[:,2] + Q_dot_vent_m_vv_S1_L + Q_dot_infiltrasjon_m_vv_S1_L)
oppvarmingsbehov_m_vv_S2_L = (Q_dot_konduksjon_L[:,1] - Q_dot_konduksjon_L[:,2] + Q_dot_vent_m_vv_S2_L + Q_dot_infiltrasjon_m_vv_S2_L)

oppvarmingsbehov_m_vv_S1_H = (Q_dot_konduksjon_H[:,0] + Q_dot_konduksjon_L[:,2] + Q_dot_vent_m_vv_S1_H + Q_dot_infiltrasjon_m_vv_S1_H)
oppvarmingsbehov_m_vv_S2_H = (Q_dot_konduksjon_H[:,1] - Q_dot_konduksjon_L[:,2] + Q_dot_vent_m_vv_S2_H + Q_dot_infiltrasjon_m_vv_S2_H)

# print(f' OPPVARM = {oppvarmingsbehov_S1_L}')

# print(f' OPPVARM = {oppvarmingsbehov_S2_L}')

# print(f' OPPVARM = {oppvarmingsbehov_S1_L[5040]}')

# print(f' OPPVARM = {oppvarmingsbehov_S2_L[5040]}')
# print(tvec_L[5040], Tuvec_L[5040])
#kanskje heller slik?
#oppvarmingsbehov_m_vv_S1 = np.sum(Q_dot_konduksjon[:,0] + Q_dot_konduksjon[:,2] + Q_dot_ventilasjon_S1 + Q_dot_infiltrasjon_S1)
#oppvarmingsbehov_m_vv_S2 = np.sum(Q_dot_konduksjon[:,1] - Q_dot_konduksjon[:,2] + Q_dot_ventilasjon_S2 + Q_dot_infiltrasjon_S2)

# 1 totalt Uten varmeveksler
total_oppvarmingsbehov_L = np. maximum(oppvarmingsbehov_S1_L,0)+ np.maximum(oppvarmingsbehov_S2_L, 0)
total_kjølebehov_L = np.minimum(oppvarmingsbehov_S1_L,0)+ np.minimum(oppvarmingsbehov_S2_L, 0)

total_oppvarmingsbehov_H = np. maximum(oppvarmingsbehov_S1_H,0)+ np.maximum(oppvarmingsbehov_S2_H, 0)
total_kjølebehov_H = np.minimum(oppvarmingsbehov_S1_H,0)+ np.minimum(oppvarmingsbehov_S2_H, 0)

# 2 totalt Med varmeveksler
total_oppvarmingsbehov_m_vv_L = np. maximum(oppvarmingsbehov_m_vv_S1_L,0)+ np.maximum(oppvarmingsbehov_m_vv_S2_L, 0)
total_kjølebehov_m_vv_L = np.minimum(oppvarmingsbehov_m_vv_S1_L,0)+ np.minimum(oppvarmingsbehov_m_vv_S2_L, 0)

total_oppvarmingsbehov_m_vv_H = np. maximum(oppvarmingsbehov_m_vv_S1_H,0)+ np.maximum(oppvarmingsbehov_m_vv_S2_H, 0)
total_kjølebehov_m_vv_H = np.minimum(oppvarmingsbehov_m_vv_S1_H,0)+ np.minimum(oppvarmingsbehov_m_vv_S2_H, 0)




"Elektrisk energibehov"
# Regn ut det elektriske energibehovet
# 1 Kølebehov
el_kjølebehov_L = 1/COP_kj * np.abs(total_kjølebehov_L)
el_kjølebehov_m_vv_L = 1/ COP_kj * np.abs(total_kjølebehov_m_vv_L)

el_kjølebehov_H = 1/COP_kj * np.abs(total_kjølebehov_H)
el_kjølebehov_m_vv_H = 1/ COP_kj * np.abs(total_kjølebehov_m_vv_H)

# 3. UTEN VARMEVEKSLER (CASE 1 & 2)
# 3.1 El.forbruk for oppvarmings/kjølebehov: el i S1, HP i S2
# el_forbruk_C1_L = (1/eta_el) * (np. maximum(oppvarmingsbehov_m_vv_S1_L,0)-np.minimum(oppvarmingsbehov_m_vv_S1_L,0)) + (1/COP_hp) * (-np.minimum(oppvarmingsbehov_m_vv_S2_L, 0)) + (1/COP_kj)* np.maximum(oppvarmingsbehov_m_vv_S2_L, 0)# elektrisk forbruk med varmepumnpe i S2
el_forbruk_C1_L = (1/eta_el) * oppvarmingsbehov_S1_L + (1/COP_kj) * oppvarmingsbehov_S2_L
el_forbruk_C1_H = (1/eta_el) * oppvarmingsbehov_S1_H + (1/COP_kj) * oppvarmingsbehov_S2_H
# el_forbruk_C1_H = (1/eta_el) * (np. maximum(oppvarmingsbehov_m_vv_S1_H,0)-np.minimum(oppvarmingsbehov_m_vv_S1_H,0)) + (1/COP_hp) * (-np.minimum(oppvarmingsbehov_m_vv_S2_H, 0)) + (1/COP_kj)* np.maximum(oppvarmingsbehov_m_vv_S2_H, 0)# elektrisk forbruk med varmepumnpe i S2





# print(f' El bubkbkbbkbkbkk = {el_forbruk_C1_L, el_forbruk_C1_H}')
# (1/eta_el) * oppvarmingsbehov_S1_H + (1/COP_hp) * oppvarmingsbehov_S2_H

# 3.2 El.forbruk for oppvarmings/kjølebehov: HP i S1, HP i S2
el_forbruk_C2_L = (1/COP_hp) * oppvarmingsbehov_S1_L + (1/COP_kj) * oppvarmingsbehov_S2_L

el_forbruk_C2_H = (1/COP_hp) * oppvarmingsbehov_S1_H + (1/COP_kj) * oppvarmingsbehov_S2_H

# 4. MED VARMEVEKSLER (CASE 3)
# 4.1 El.forbruk for oppvarmings/kjølebehov: HP i S1, HP i S2
el_forbruk_C3_L = (1/COP_hp) * oppvarmingsbehov_m_vv_S1_L + (1/COP_kj) * oppvarmingsbehov_m_vv_S2_L

el_forbruk_C3_H = (1/COP_hp) * oppvarmingsbehov_m_vv_S1_H + (1/COP_kj) * oppvarmingsbehov_m_vv_S2_H



"Besparelse "
# Regn ut energibesparelser
besp1_2_L = (el_forbruk_C1_L - el_forbruk_C2_L)  #kwh/år
besp1_3_L = (el_forbruk_C1_L - el_forbruk_C3_L)  #kwh/år

besp1_2_H = (el_forbruk_C1_H - el_forbruk_C2_H)  #kwh/år
besp1_3_H = (el_forbruk_C1_H - el_forbruk_C3_H)  #kwh/år

Wbesp12aar_L = np.sum(besp1_2_L)
Wbesp13aar_L = np.sum(besp1_3_L)

Wbesp12aar_H = np.sum(besp1_2_H)
Wbesp13aar_H = np.sum(besp1_3_H)

# print('\n \n')
# print('Besparelse strømbehov:')
# print(f'   Ved installering av HP (Case 1 til 2):          {round(Wbesp12aar_L)} kWh/år')
# print(f'   Ved installering av HP & VV (Case 1 til 3):     {round(Wbesp13aar_L)} kWh/år')

# print(f'   Ved installering av HP (Case 1 til 2):          {round(Wbesp12aar_H)} kWh/år')
# print(f'   Ved installering av HP & VV (Case 1 til 3):     {round(Wbesp13aar_H)} kWh/år')



"Måndesgjennomsnitt"
 

# Calculate daily averages
T_u_reshaped_L = Tuvec_L.reshape(365,24)
T_U_daily_avg_L = np.mean(T_u_reshaped_L, axis = 1)

T_u_reshaped_H = Tuvec_H.reshape(365,24)
T_U_daily_avg_H = np.mean(T_u_reshaped_H, axis = 1)

# print(f' EL forbruk C1 = {el_forbruk_C1_L}')

el_forbruk_C1_reshaped_L = el_forbruk_C1_L.reshape(365, 24)
el_forbruk_C1_daily_sum_L = np.mean(el_forbruk_C1_reshaped_L, axis = 1)

el_forbruk_C1_reshaped_H = el_forbruk_C1_H.reshape(365, 24)
el_forbruk_C1_daily_sum_H = np.mean(el_forbruk_C1_reshaped_H, axis = 1)

el_forbruk_C2_reshaped_L = el_forbruk_C2_L.reshape(365, 24)
el_forbruk_C2_daily_sum_L = np.mean(el_forbruk_C2_reshaped_L, axis = 1)

el_forbruk_C2_reshaped_H = el_forbruk_C2_H.reshape(365, 24)
el_forbruk_C2_daily_sum_H = np.mean(el_forbruk_C2_reshaped_H, axis = 1)

el_forbruk_C3_reshaped_L = el_forbruk_C3_L.reshape(365, 24)
el_forbruk_C3_daily_sum_L = np.mean(el_forbruk_C3_reshaped_L, axis = 1)

el_forbruk_C3_reshaped_H = el_forbruk_C3_H.reshape(365, 24)
el_forbruk_C3_daily_sum_H = np.mean(el_forbruk_C3_reshaped_H, axis = 1)

# print(f'Måned snitt = {el_forbruk_C1_reshaped_L}')
# print(len(el_forbruk_C1_reshaped_L))
# Calculate monthly averages
T_u_reshaped_L = Tuvec_L.reshape(12,730)
T_U_monthly_avg_L = np.mean(T_u_reshaped_L, axis = 1)

T_u_reshaped_H = Tuvec_H.reshape(12,730)
T_U_monthly_avg_H = np.mean(T_u_reshaped_H, axis = 1)

el_forbruk_C1_reshaped_Lm = el_forbruk_C1_L.reshape(12, 730)
el_forbruk_C1_monthly_L = np.mean(el_forbruk_C1_reshaped_L, axis = 1)

el_forbruk_C1_reshaped_H = el_forbruk_C1_H.reshape(12, 730)
el_forbruk_C1_monthly_H = np.mean(el_forbruk_C1_reshaped_H, axis = 1)

el_forbruk_C2_reshaped_L = el_forbruk_C2_L.reshape(12, 730)
el_forbruk_C2_monthly_L = np.mean(el_forbruk_C2_reshaped_L, axis = 1)

el_forbruk_C2_reshaped_H = el_forbruk_C2_H.reshape(12, 730)
el_forbruk_C2_monthly_H = np.mean(el_forbruk_C2_reshaped_H, axis = 1)

el_forbruk_C3_reshaped_L = el_forbruk_C3_L.reshape(12, 730)
el_forbruk_C3_monthly_L = np.mean(el_forbruk_C3_reshaped_L, axis = 1)

el_forbruk_C3_reshaped_H = el_forbruk_C3_H.reshape(12, 730)
el_forbruk_C3_monthly_H = np.mean(el_forbruk_C3_reshaped_H, axis = 1)

# print("==========================================================")
# print(f'Måned### ============================================{el_forbruk_C1_reshaped_Lm}')
# print(len(el_forbruk_C1_reshaped_Lm))

# Clear variables (optional in Python, as memory management is handled by Python's garbage collector)

# Display the monthly averages DataFrame


"Plotting"
# Lag grafer for å visualisere resultater

# Plotting daily averages


# Plotting monthly averages (søyle)
bar_with = 0.2 
bar_posision_C1 = np.arange(1,13)
bar_posision_C2 = bar_posision_C1 + bar_with
bar_posision_C3 = bar_posision_C2 + bar_with






# Lagre data i .npy file
#np.save('Sted1_T.npy', Tuvec)
#np.save('Sted1_Besparelse12.npy', Wbesp12)
#np.save('Sted1_Besparelse13.npy', Wbesp13)
#np.save('Sted1_ForbrukC1.npy', Wvarme_C1)
#np.save('Sted1_ForbrukC2.npy', Wvarme_C2)
#np.save('Sted1_ForbrukC3.npy', Wvarme_C3)



# import os


# energi_ut_s2_s1 = U_S1_S2 * ((R3_L+R3_B)*RH) * (T_o-T_k)
# energi_ut_s2_L = U_ut_S2_eks_S1 * (A_tot_GTS2) * (T_k - Tuvec_L)
# total_energitap2_L = (energi_ut_s2_s1 + energi_ut_s2_L)



# energi_ut_s1_H = U_ut_S1_eks_S2 * (A_tot_GTS1) * (T_o - Tuvec_H)
# energi_ut_s2_H = U_ut_S2_eks_S1 * (A_tot_GTS2) * (T_k - Tuvec_H)
# total_energitap2_H = (energi_ut_s2_s1 + energi_ut_s2_H)




# energi_ut_s1_s2 = U_S1_S2 * ((R3_B+R3_L)*RH) * (T_o-T_k)
# energi_ut_s1_L = U_ut_S1_eks_S2 * (A_tot_GTS1) * (T_o - Tuvec_L)
# total_energitap1_L = (energi_ut_s1_s2 + energi_ut_s1_L)


# energi_ut_s1_H = U_ut_S1_eks_S2 * (A_tot_GTS1) * (T_o - Tuvec_H)
# total_energitap1_H = (energi_ut_s1_s2 + energi_ut_s1_H)



# # 3. UTEN VARMEVEKSLER (CASE 1 & 2)


# # 3.1 El.forbruk for oppvarmings/kjølebehov: el i S1, HP i S2

# El_forbruk1L = total_energitap1_L / eta_el + total_energitap2_L / COP_kj 
# El_forbruk1H = total_energitap1_H / eta_el + total_energitap2_H / COP_kj


# # 3.2 El.forbruk for oppvarmings/kjølebehov: HP i S1, HP i S2

# El_forbruk2L = total_energitap1_L / COP_hp + total_energitap2_L / COP_kj
# El_forbruk2H = total_energitap1_H / COP_hp + total_energitap2_H / COP_kj


# # 4. MED VARMEVEKSLER (CASE 3)


# # 4.1 El.forbruk for oppvarmings/kjølebehov: HP i S1, HP i S2

# El_forbruk3L = (eta_vv * total_energitap1_L / COP_hp) + (eta_vv * total_energitap2_L / COP_kj)
# El_forbruk3H = (eta_vv * total_energitap1_H / COP_hp) + (eta_vv * total_energitap2_H / COP_kj)


# def plot_monthly(data, title, color='blue'):
#     grupper = [data[i:i + 730] for i in range(0, len(data), 730)]
#     summer_per_måned = [sum(gruppe) for gruppe in grupper]

#     month = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
#     fig, ax = plt.subplots(1, 1)
#     ax.bar(month, summer_per_måned, color=color)
#     ax.set(xlabel='Måned', ylabel='Effekt')
#     ax.set_title(title) 
#     plt.show()



def plot_monthly_multi(data_list, title_list, overhead, colors='blue'):
    if colors is None:
        colors = ['blue', 'green', 'red', 'purple', 'orange']  # Add more colors if needed

    fig, ax = plt.subplots(1, 1)
    
    for i, data in enumerate(data_list):
        grupper = [data[j:j + 730] for j in range(0, len(data), 730)]
        summer_per_måned = [sum(gruppe) for gruppe in grupper]

        month = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

        ax.bar(month, summer_per_måned, color=colors[i], label=title_list[i])

    ax.set(xlabel='Måned', ylabel='Effekt [kW]')
    ax.set_title(overhead)
    ax.legend()
    plt.show()

# Example usage:

el_C1_L_plot = el_forbruk_C1_L/1000

el_C2_L_plot = el_forbruk_C2_L/1000

el_C3_L_plot = el_forbruk_C3_L/1000

el_C1_H_plot = el_forbruk_C1_H/1000

el_C2_H_plot = el_forbruk_C2_H/1000

el_C3_H_plot = el_forbruk_C3_H/1000



plot_monthly_multi([el_C1_L_plot, el_C2_L_plot, el_C3_L_plot], ['Scenario 1', 'Scenario 2', 'Scenario 3'], 'Lyngdal', ['green', 'red', 'blue'])
plot_monthly_multi([el_C1_H_plot, el_C2_H_plot, el_C3_H_plot], ['Scenario 1', 'Scenario 2', 'Scenario 3'], 'Harstad', ['green', 'red', 'blue'])

# def plot_monthly(data, title, color='blue'):
#     ant_set = len(data)
#     for j in range(ant_set):
#         grupper = [data[i:i + 730] for i in range(0, len(data), 730)]
#         summer_per_måned = [sum(gruppe) for gruppe in grupper]

#         month = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
#         fig, ax = plt.subplots(1, 1)
#         ax.bar(month, summer_per_måned, color=color)
#         ax.set(xlabel='Måned', ylabel='Effekt')
#         ax.set_title(title) 
#     plt.show()




def plot_comparison_chart():
    fig, ax = plt.subplots(1, 1)
    ax.plot(tvec_L, Tuvec_L, label='Lyngdal', color='green')
    ax.plot(tvec_H, Tuvec_H, label='Harstad', color='red')
    ax.set_xlabel('Tid')
    ax.set_ylabel('Temp [C]')
    ax.set_title('Temperatur 2023')
    ax.legend()
    plt.show()



# plot_monthly((el_forbruk_C1_L, '1', 'g'), (el_forbruk_C2_L, '2', 'r'))

# plot_monthly(el_forbruk_C1_L, 'Lyngdal_1', 'green')
# plot_monthly(el_forbruk_C1_H, 'Harstad_1', 'red')
# plot_monthly(el_forbruk_C2_L, 'Lyngdal_2', 'blue')
# plot_monthly(el_forbruk_C2_H, 'Harstad_2', 'yellow')
# plot_monthly(el_forbruk_C3_L, 'Lyngdal_3', 'orange')
# plot_monthly(el_forbruk_C3_H, 'Harstad_3', 'pink')

plot_comparison_chart()

# print(f'C1 forbruk L {round(np.sum(el_forbruk_C1_L), 0)}')
# print(f'C2 forbruk L {round(np.sum(el_forbruk_C2_L), 0)}')
# print(f'C3 forbruk L {round(np.sum(el_forbruk_C3_L), 0)}')

# print(f'C1 forbruk H {round(np.sum(el_forbruk_C1_H), 0)}')
# print(f'C2 forbruk H {round(np.sum(el_forbruk_C2_H), 0)}')
# print(f'C3 forbruk H {round(np.sum(el_forbruk_C3_H), 0)}')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

"Load data"
Esol_H = np.load('Solenergi_H.npy')                 #8760   #W
Esol_L = np.load('Solenergi_L.npy')                 #8760   #W
Pvind_H = np.load('Harstad_EprodVind.npy')          #8760   #kW
Pvind_L = np.load('Lyngdal_EprodVind.npy')          #8760   #kW

kWvarme_C1_H = np.load('Harstad_ForbrukC1.npy')    #8760    #kW
kWvarme_C2_H = np.load('Harstad_ForbrukC2.npy')    #8760    #kW
kWvarme_C3_H = np.load('Harstad_ForbrukC3.npy')    #8760    #kW

kWvarme_C1_L = np.load('Lyngdal_ForbrukC1.npy')    #8760    #kW
kWvarme_C2_L = np.load('Lyngdal_ForbrukC2.npy')    #8760    #kW
kWvarme_C3_L = np.load('Lyngdal_ForbrukC3.npy')    #8760    #kW

Esol_kW_H = Esol_H/1000
Esol_kW_L = Esol_L/1000

print(len(Pvind_H), len(Pvind_L))



"================Energiberegninger================="

"==Besparelse C1-C2=="
def besparelse(C1, C2):
    Besp = C1 - C2
    return Besp

Besp_H = besparelse(kWvarme_C1_H, kWvarme_C2_H)
Besp_L = besparelse(kWvarme_C1_L, kWvarme_C2_L)

"==Netto strømproduksjon=="
def Netto_Eprod(Sol, Vind, Label):
    Netto_Eprod = Sol + Vind; Label
    return Netto_Eprod

Netto_Eprod_H = Netto_Eprod(Esol_kW_H, Pvind_H, 'Netto_Harstad')
Netto_Eprod_L = Netto_Eprod(Esol_kW_L, Pvind_L, 'Netto_Lyngdal')


"==Netto forbruk - egenprodusert=="
def Netto_forbruk_inkl_Eprod(Forbruk, Produsert):
    Netto_m_egenprod = Forbruk - Produsert
    return Netto_m_egenprod

Netto_forbruk_C1_H = Netto_forbruk_inkl_Eprod(kWvarme_C1_H, Netto_Eprod_H)
Netto_forbruk_C2_H = Netto_forbruk_inkl_Eprod(kWvarme_C2_H, Netto_Eprod_H)
Netto_forbruk_C3_H = Netto_forbruk_inkl_Eprod(kWvarme_C3_H, Netto_Eprod_H)

Netto_forbruk_C1_L = Netto_forbruk_inkl_Eprod(kWvarme_C1_L, Netto_Eprod_L)
Netto_forbruk_C2_L = Netto_forbruk_inkl_Eprod(kWvarme_C2_L, Netto_Eprod_L)
Netto_forbruk_C3_L = Netto_forbruk_inkl_Eprod(kWvarme_C3_L, Netto_Eprod_L)



"==Variabelt antall solceller=="
Etot_S_H = np.sum(Esol_kW_H)
W_C1_H = np.sum(kWvarme_C1_H)
W_C2_H = np.sum(kWvarme_C2_H)
W_C3_H = np.sum(kWvarme_C3_H)

Etot_S_L = np.sum(Esol_kW_L)
W_C1_L = np.sum(kWvarme_C1_L)
W_C2_L = np.sum(kWvarme_C2_L)
W_C3_L = np.sum(kWvarme_C3_L)



n_S_H = np.arange(0, 12, 1) # solpaneller
E_s_prod_C1_H = Etot_S_H * n_S_H - W_C1_H  #kWh
E_s_prod_C2_H = Etot_S_H * n_S_H - W_C2_H  #kWh
E_s_prod_C3_H = Etot_S_H * n_S_H - W_C3_H  #kWh


n_S_L = np.arange(0, 12, 1) # solpaneller
E_s_prod_C1_L = Etot_S_L * n_S_L - W_C1_L  #kWh
E_s_prod_C2_L = Etot_S_L * n_S_L - W_C2_L  #kWh
E_s_prod_C3_L = Etot_S_L * n_S_L - W_C3_L  #kWh


"Plotting "

def plot_multiple_arrays(array1, array2, array3, colors=None, labels=None, title=None, xlabel=None):
    plt.figure(figsize=(10, 6))
    
    # Plot array1
    if colors and labels:
        plt.plot(array1, color=colors[0], label=labels[0])
    else:
        plt.plot(array1)
    
    # Plot array2
    if colors and labels:
        plt.plot(array2, color=colors[1], label=labels[1])
    else:
        plt.plot(array2)
    
    # Plot array3
    if colors and labels:
        plt.plot(array3, color=colors[2], label=labels[2])
    else:
        plt.plot(array3)
    
    plt.xlabel(xlabel)
    plt.ylabel('Netto effekt')
    if title:
        plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.show()


colors = ['red', 'green', 'blue']
labels = ['Scenario 1', 'Scenario 2', 'Scenario 3']



"Variabelt antall vindturbiner"
n_s = np.arange(0, 12, 1) # solpaneller

Etot_V_H = np.sum(Pvind_H)
E_t_prod_C1_H = Etot_V_H * n_s - W_C1_H  #kWh
E_t_prod_C2_H = Etot_V_H * n_s - W_C2_H  #kWh
E_t_prod_C3_H = Etot_V_H * n_s - W_C3_H  #kWh

Etot_V_L = np.sum(Pvind_L)
E_t_prod_C1_L = Etot_V_L * n_s - W_C1_L  #kWh
E_t_prod_C2_L = Etot_V_L * n_s - W_C2_L  #kWh
E_t_prod_C3_L = Etot_V_L * n_s - W_C3_L  #kWh





"Kostnader"

"==kWh Kjøpt=="

def Etot_Kjøp(forbruk):
    Kjøp = []
    for i in forbruk:
        if i > 0:
            Kjøp.append(i)
        else:
            Kjøp.append(0)
    return Kjøp

E_Kjøpt_C1_H = Etot_Kjøp(Netto_forbruk_C1_H)
E_Kjøpt_C2_H = Etot_Kjøp(Netto_forbruk_C2_H)
E_Kjøpt_C3_H = Etot_Kjøp(Netto_forbruk_C3_H)
E_Kjøpt_C1_L = Etot_Kjøp(Netto_forbruk_C1_L)
E_Kjøpt_C2_L = Etot_Kjøp(Netto_forbruk_C2_L)
E_Kjøpt_C3_L = Etot_Kjøp(Netto_forbruk_C3_L)


"==kWh Solgt=="

def Etot_solgt(forbruk):
    Selg = []
    for i in forbruk:
        if i < 0:
            Selg.append(i)
        else:
            Selg.append(0)
    return Selg

E_Solgt_C1_H = Etot_solgt(Netto_forbruk_C1_H)
E_Solgt_C2_H = Etot_solgt(Netto_forbruk_C2_H)
E_Solgt_C3_H = Etot_solgt(Netto_forbruk_C3_H)
E_Solgt_C1_L = Etot_solgt(Netto_forbruk_C1_L)
E_Solgt_C2_L = Etot_solgt(Netto_forbruk_C2_L)
E_Solgt_C3_L = Etot_solgt(Netto_forbruk_C3_L)


"==Kun solceller=="

kWvarme_C3_H
kWvarme_C3_L
Evarme_tot_C3_H = np.sum(kWvarme_C3_H)
Evarme_tot_C3_L = np.sum(kWvarme_C3_L)

Esol_kW_H
Esol_kW_L
Esol_1m2_H = Etot_S_H / 10
Esol_1m2_L = Etot_S_L / 10






def num_sources(Source, Evarme):
    num_sources = 0
    Power = 0
    
    for i in range(1, int(Source) + 1):  
        if Power < Evarme:
            num_sources += 1
            Power += Source
            
        else:
            return num_sources
    return num_sources  


num_cell_H = num_sources(Esol_1m2_H, Evarme_tot_C3_H)
num_cell_L = num_sources(Esol_1m2_L, Evarme_tot_C3_L)


"==Kun vindturbiner=="

num_turbin_H = num_sources(Etot_V_H, Evarme_tot_C3_H)
num_turbin_L = num_sources(Etot_V_L, Evarme_tot_C3_L)


t = np.arange(1, 8761)

pstrøm = 0.68 + 0.15 * np.cos((2 * np.pi * t) / 8760 - np.pi / 8)

pnett = 0.65 - 0.15 * np.cos((2 * np.pi * t) / 8760)

"Oppgave 1"
Netto_strømpris = pstrøm + pnett

"Oppgave 2"
psalg = np.sqrt(pstrøm / (np.sum(pstrøm) / 8760))


"Oppgave 3"
def yearly_cost(kjøpt, pris):
    yearly_cost = kjøpt * pris
    return yearly_cost    


Yearly_cost_C1_H = yearly_cost(E_Kjøpt_C1_H, Netto_strømpris)
Yearly_cost_C2_H = yearly_cost(E_Kjøpt_C2_H, Netto_strømpris)
Yearly_cost_C3_H = yearly_cost(E_Kjøpt_C3_H, Netto_strømpris)
Yearly_cost_C1_L = yearly_cost(E_Kjøpt_C1_L, Netto_strømpris)
Yearly_cost_C2_L = yearly_cost(E_Kjøpt_C2_L, Netto_strømpris)
Yearly_cost_C3_L = yearly_cost(E_Kjøpt_C3_L, Netto_strømpris)



"Oppgave 4"

def yearly_sold(sold, price):
    yearly_sold = sold * price
    return yearly_sold

Yearly_Sold_C1_H = yearly_sold(E_Solgt_C1_H, psalg)
Yearly_Sold_C2_H = yearly_sold(E_Solgt_C2_H, psalg)
Yearly_Sold_C3_H = yearly_sold(E_Solgt_C3_H, psalg)
Yearly_Sold_C1_L = yearly_sold(E_Solgt_C1_L, psalg)
Yearly_Sold_C2_L = yearly_sold(E_Solgt_C2_L, psalg)
Yearly_Sold_C3_L = yearly_sold(E_Solgt_C3_L, psalg)


"oppgave 5"
def yearly_saved(besp, price):
    yearly_saved = besp * price
    return yearly_saved

yearly_saved_H = yearly_saved(Besp_H, Netto_strømpris)
yearly_saved_L = yearly_saved(Besp_L, Netto_strømpris)




"Oppgave 6"

"Ingen salg av strøm"

def yearly_saved_pr_unit(Prod, Usage):
    yearly_saved_V = []
    for i, j in zip(Prod, Usage):
        if i <= j:
            yearly_saved_V.append(i)
        else:
            yearly_saved_V.append(j)
    yearly_saved_V_kr = yearly_saved_V * Netto_strømpris
    return yearly_saved_V_kr

yearly_saved_turbine_C1_H = yearly_saved_pr_unit(Pvind_H, kWvarme_C1_H)
yearly_saved_turbine_C2_H = yearly_saved_pr_unit(Pvind_H, kWvarme_C2_H)
yearly_saved_turbine_C3_H = yearly_saved_pr_unit(Pvind_H, kWvarme_C3_H)
yearly_saved_turbine_C1_L = yearly_saved_pr_unit(Pvind_L, kWvarme_C1_L)
yearly_saved_turbine_C2_L = yearly_saved_pr_unit(Pvind_L, kWvarme_C2_L)
yearly_saved_turbine_C3_L = yearly_saved_pr_unit(Pvind_L, kWvarme_C3_L)



"Oppgave 7"

yearly_saved_Solar_C1_H = yearly_saved_pr_unit(Esol_H, kWvarme_C1_H)
yearly_saved_Solar_C2_H = yearly_saved_pr_unit(Esol_H, kWvarme_C2_H)
yearly_saved_Solar_C3_H = yearly_saved_pr_unit(Esol_H, kWvarme_C3_H)
yearly_saved_Solar_C1_L = yearly_saved_pr_unit(Esol_L, kWvarme_C1_L)
yearly_saved_Solar_C2_L = yearly_saved_pr_unit(Esol_L, kWvarme_C2_L)
yearly_saved_Solar_C3_L = yearly_saved_pr_unit(Esol_L, kWvarme_C3_L)



"Nåverdi"
N_sol, N_vind, N_VP = 30, 15, 12 # år                                   Levetid
I_sol, I_vind, I_VP = 2000, 50000, 9000 # kr/m**2, kr/turbin, kr/VP     Investeringskostnad
V_sol, V_vind, V_VP = 30, 200, 250 # kr/år/m**2, kr/år/turbin, kr/år    Vedlikeholdskostnad
r = 0.07 #                                                              Rente

def nåverdi(Esol, Pvind, VP):
    NV_sol = -I_sol*10  -  V_sol*10*((1-(1+r)**(-N_sol))/r)  +  Esol*((1-(1+r)**(-N_sol))/r)
    NV_vind = -I_vind  -  V_vind*((1-(1+r)**(-N_vind))/r)  +  Pvind*((1-(1+r)**(-N_vind))/r)
    NV_VP = -I_VP  -  V_VP*((1-(1+r)**(-N_VP))/r)  +  VP*((1-(1+r)**(-N_VP))/r)
    return NV_sol, NV_vind, NV_VP

NV_sol_L, NV_vind_L, NV_VP_L = nåverdi(np.sum(yearly_saved_Solar_C1_L), np.sum(yearly_saved_turbine_C1_L), np.sum(kWvarme_C1_L * Netto_strømpris)-np.sum(kWvarme_C2_L * Netto_strømpris)) #Har tatt kroner minus watt som ikke fungerer så bra
NV_sol_H, NV_vind_H, NV_VP_H = nåverdi(np.sum(yearly_saved_Solar_C1_H), np.sum(yearly_saved_turbine_C1_H), np.sum(kWvarme_C1_H * Netto_strømpris)-np.sum(kWvarme_C2_H * Netto_strømpris)) #Har tatt kroner minus watt som ikke fungerer så bra




"Klimagass"

Norsk_utslipp = 0.0189 #kgCO2/kWh
Euro_utslipp = 0.3 #kgCO2/kWh
K_sol, K_vind, K_VP = 7000 * 3, 700 * 0.78, 1800 #kgCO2/kW

def klimagass(elforbruk_C1, elforbruk_C3 , energi_vind, energi_sol):
    Kun_Norskstrøm = np.sum(elforbruk_C1) * Norsk_utslipp * 10
    Kun_Eurostrøm = np.sum(elforbruk_C1) * Euro_utslipp * 10
    Norskstrøm_vind_sol = (np.sum(elforbruk_C3)-np.sum(energi_vind)-np.sum(energi_sol)) * Norsk_utslipp * 10 + K_sol + K_vind + K_VP
    
    return Kun_Norskstrøm, Kun_Eurostrøm, Norskstrøm_vind_sol

Kun_Norskstrøm_L, Kun_Eurostrøm_L, Norskstrøm_vind_sol_L = klimagass(kWvarme_C1_L, kWvarme_C2_L, Pvind_L, Esol_kW_L)
Kun_Norskstrøm_H, Kun_Eurostrøm_H, Norskstrøm_vind_sol_H = klimagass(kWvarme_C1_H, kWvarme_C2_H, Pvind_H, Esol_kW_H)



" Print or use the values as needed"
plot_multiple_arrays(E_s_prod_C1_H, E_s_prod_C2_H, E_s_prod_C3_H, colors=colors, labels=labels, title='Harstad', xlabel="x10 m² Solcellepaneler")
plot_multiple_arrays(E_s_prod_C1_L, E_s_prod_C2_L, E_s_prod_C3_L, colors=colors, labels=labels, title='Lyngdal', xlabel="x10 m² Solcellepaneler")

plot_multiple_arrays(E_t_prod_C1_H, E_t_prod_C2_H, E_t_prod_C3_H, colors=colors, labels=labels, title='Harstad', xlabel="Antall Turbiner")
plot_multiple_arrays(E_t_prod_C1_L, E_t_prod_C2_L, E_t_prod_C3_L, colors=colors, labels=labels, title='Lyngdal', xlabel="Antall Turbiner")

print("===============================================")
print("===================Mikrogrid===================")
print("===============================================")
print("")
print("===============Energiberegninger===============")
print("")
print("Kjøpt energi for:")
print("")
print("Harstad")
print(f'Scenario 1: {round(np.sum(E_Kjøpt_C1_H))} kWh')
print(f'Scenario 2: {round(np.sum(E_Kjøpt_C2_H))} kWh')
print(f'Scenario 3: {round(np.sum(E_Kjøpt_C3_H))} kWh')
print("")
print("Lyngdal")
print(f'Scenario 1: {round(np.sum(E_Kjøpt_C1_L))} kWh')
print(f'Scenario 2: {round(np.sum(E_Kjøpt_C2_L))} kWh')
print(f'Scenario 3: {round(np.sum(E_Kjøpt_C3_L))} kWh')
print("")
print("===============================================")
print("")
print("Solgt energi for:")
print("")
print("Harstad")
print(f'Scenario 1 Harstad: {round(abs(np.sum(E_Solgt_C1_H)))} kWh')
print(f'Scenario 2 Harstad: {round(abs(np.sum(E_Solgt_C2_H)))} kWh')
print(f'Scenario 3 Harstad: {round(abs(np.sum(E_Solgt_C3_H)))} kWh')
print("")
print("Lyngdal")
print(f'Scenario 1 Lyngdal: {round(abs(np.sum(E_Solgt_C1_L)))} kWh')
print(f'Scenario 2 Lyngdal: {round(abs(np.sum(E_Solgt_C2_L)))} kWh')
print(f'Scenario 3 Lyngdal: {round(abs(np.sum(E_Solgt_C3_L)))} kWh')

print("")
print("===============================================")
print("")
print("Antall kvadratmeter solcellepaneler nødvendig for å ikke kjøpe noe strøm i scenario 3")
print(f'Harstad: {num_cell_H}')
print(f'Lyngdal: {num_cell_L}')

print("")
print("===============================================")
print("")
print("Antall vindturbiner nødvendige for å ikke kjøpe noe strøm i scenario 3")
print(f'Harstad: {num_turbin_H}')
print(f'Lyngdal: {num_turbin_L}')

print("")
print("==================Kostnader====================")
print("")
print("")
print("=============Årlig kostnad strøm===============")
print("")

print("Harstad")

print(f'Scenario 1 total: {round(np.sum(Yearly_cost_C1_H))} kr')
print(f'Scenario 2 total: {round(np.sum(Yearly_cost_C2_H))} kr')
print(f'Scenario 3 total: {round(np.sum(Yearly_cost_C3_H))} kr')

print("")

print("Lyngdal:")

print(f'Scenario 1 total: {round(np.sum(Yearly_cost_C1_L))} kr')
print(f'Scenario 2 total: {round(np.sum(Yearly_cost_C2_L))} kr')
print(f'Scenario 3 total: {round(np.sum(Yearly_cost_C3_L))} kr')

print("")
print("")
print("==============Årlig inntekt strøm==============")
print("")

print("Harstad")

print(f'Scenario 1 total: {round(abs(np.sum(Yearly_Sold_C1_H)))} kr')
print(f'Scenario 2 total: {round(abs(np.sum(Yearly_Sold_C2_H)))} kr')
print(f'Scenario 3 total: {round(abs(np.sum(Yearly_Sold_C3_H)))} kr')

print("")

print("Lyngdal:")

print(f'Scenario 1 total: {round(abs(np.sum(Yearly_Sold_C1_L)))} kr')
print(f'Scenario 2 total: {round(abs(np.sum(Yearly_Sold_C2_L)))} kr')
print(f'Scenario 3 total: {round(abs(np.sum(Yearly_Sold_C3_L)))} kr')

print("")
print("")
print("====Årling kostnadsbesparelse med varmepumpe====")
print("")
print("Harstad:")
print(round(np.sum(yearly_saved_H)), "kr")
print("")
print("Lyngdal")
print(round(np.sum(yearly_saved_L)), "kr")
print("")
print("")
print("====================Årlig besparelse med en turbin uten salg av strøm===================")
print("")
print("Harstad:")
print("Scenario 1: ",round(np.sum(yearly_saved_turbine_C1_H)), "kr")
print("Scenario 2: ",round(np.sum(yearly_saved_turbine_C2_H)), "kr")
print("Scenario 3: ",round(np.sum(yearly_saved_turbine_C3_H)), "kr")
print("")
print("Lyngdal")
print("Scenario 1: ",round(np.sum(yearly_saved_turbine_C1_L)), "kr")
print("Scenario 2: ",round(np.sum(yearly_saved_turbine_C2_L)), "kr")
print("Scenario 3: ",round(np.sum(yearly_saved_turbine_C3_L)), "kr")
print("")
print("")
print("====================Årlig besparelse med 10m2 solcelle uten salg av strøm===================")
print("")
print("Harstad:")
print("Scenario 1: ",round(np.sum(yearly_saved_Solar_C1_H)), "kr")
print("Scenario 2: ",round(np.sum(yearly_saved_Solar_C2_H)), "kr")
print("Scenario 3: ",round(np.sum(yearly_saved_Solar_C3_H)), "kr")
print("")
print("Lyngdal")
print("Scenario 1: ",round(np.sum(yearly_saved_Solar_C1_L)), "kr")
print("Scenario 2: ",round(np.sum(yearly_saved_Solar_C2_L)), "kr")
print("Scenario 3: ",round(np.sum(yearly_saved_Solar_C3_L)), "kr")
print("")
print("")
print("========================Nåverdi========================")
print("")
print("Harstad:")
print(f"Sol:         {round(NV_sol_H):<8} kr")
print(f"Vind:        {round(NV_vind_H):<8} kr")
print(f"Varmepumpe:  {round(NV_VP_H):<8} kr")
print("")
print("Lyngdal:")
print(f"Sol:         {round(NV_sol_L):<8} kr")
print(f"Vind:        {round(NV_vind_L):<8} kr")
print(f"Varmepumpe:  {round(NV_VP_L):<8} kr")
print("")
print("")
print("========================Klimagass========================")
print("")
print("Harstad:")
print(f"{f'Kun norsk strøm:':<40} {round(Kun_Norskstrøm_H):>6} kg CO2")
print(f"{f'Kun europeisk strøm:':<40} {round(Kun_Eurostrøm_H):>6} kg CO2")
print(f"{f'Norsk strøm, solceller og vindmøller:':<40} {round(Norskstrøm_vind_sol_H):>6} kg CO2")
print("")
print("Lyngdal:")
print(f"{f'Kun norsk strøm:':<40} {round(Kun_Norskstrøm_L):>6} kg CO2")
print(f"{f'Kun europeisk strøm:':<40} {round(Kun_Eurostrøm_L):>6} kg CO2")
print(f"{f'Norsk strøm, solceller og vindmøller:':<40} {round(Norskstrøm_vind_sol_L):>6} kg CO2")
print("")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

A = 10  # m**2
skip_last_lines = 10

#   Lager en funksjon som henter tidspunkter, solinnstråling, temperatur, virkningsgrad og energiproduksjon, alle med 8760 punkter
def f_solinnstråling_import(filnavn):
    data = pd.read_csv(filnavn, delimiter=',', decimal='.', header=6)
    data = data.head(-skip_last_lines)
    
    tvec = pd.to_datetime(data.iloc[:,0], format='%Y%m%d:%H%M').to_numpy()
    svec = data.iloc[:,1].to_numpy()
    Tuvec =  data.iloc[:,2] 
    virkningsgrad = np.where((Tuvec+20) > 25, 0.20 - 0.003 * ((Tuvec+20) - 25), np.where((Tuvec+20) < 25, 0.20 + 0.003 * (25 - (Tuvec+20)), 0.20))
    svec = svec.astype(float)
    energi = virkningsgrad * svec * np.array(A)/1000
    return tvec, svec, Tuvec, virkningsgrad, energi

#   Setter inn filene med informasjon fra Harstad og Lyngdal i funksjonen over
tvec_H, svec_H, Tuvec_H, virkningsgrad_H, energi_H = f_solinnstråling_import('Soldata_Harstad.csv')
tvec_L, svec_L, Tuvec_L, virkningsgrad_L, energi_L = f_solinnstråling_import('Soldata_Lyngdal.csv')


#   Lager en funksjon som overfører verdiene til lister med 12 verdier, altså verdier for hver måned
def calculate_monthly_energy(tvec, svec, virkningsgrad, A=10):
    tvec_datetime = pd.to_datetime(tvec)

    månedlig_energi = pd.DataFrame({'Energi': virkningsgrad * svec * np.array(A) / 1000}, index=tvec_datetime).resample('M').sum()
    månedlig_energi = månedlig_energi['Energi'].values.tolist()
    månedlig_virkningsgrad = pd.DataFrame({'Virkningsgrad': virkningsgrad}, index=tvec_datetime).resample('M').mean()
    månedlig_virkningsgrad = månedlig_virkningsgrad['Virkningsgrad'].values.tolist()
    månedlig_innstråling = pd.DataFrame({'Innstråling': svec}, index=tvec_datetime).resample('M').mean()
    månedlig_innstråling = månedlig_innstråling['Innstråling'].values.tolist()
    
    return månedlig_energi, månedlig_virkningsgrad, månedlig_innstråling

#   Setter inn timesverdiene fra Harstad og Lyngdal inn i funksjonen over
månedlig_energi_H, månedlig_virkningsgrad_H, månedlig_innstråling_H = calculate_monthly_energy(tvec_H, svec_H, virkningsgrad_H)
månedlig_energi_L, månedlig_virkningsgrad_L, månedlig_innstråling_L = calculate_monthly_energy(tvec_L, svec_L, virkningsgrad_L)


#   Verdier for plotting av grafer
måneder = ['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Des']
datasets_virkningsgrad = [månedlig_virkningsgrad_H, månedlig_virkningsgrad_L]
datasets_innstråling = [månedlig_innstråling_H, månedlig_innstråling_L]
datasets_energi = [månedlig_energi_H, månedlig_energi_L]
colors = ['skyblue', 'salmon']
width = 0.35
x = np.arange(len(måneder))
print(np.sum(månedlig_innstråling_H), np.sum(månedlig_innstråling_L))
#   Lager en funksjon for å produsere linjegrafer og søylegrafer
def plot_data(data, ylabel, title):
    plt.figure(figsize=(12, 6))
    for i, dataset in enumerate(data, start=1):
        data_per_month = [np.mean(np.array_split(dataset, 12)[j]) for j in range(12)]
        label_text = 'Harstad' if i == 1 else 'Lyngdal'
        x_offset = i - 1 - 0.5 * width
        if ylabel == 'Solinnstråling (gjennomsnitt)' or ylabel == 'Virkningsgrad (gjennomsnitt)':
            plt.plot(måneder, data_per_month, label=label_text, color=colors[i-1], marker='o')
        else:
            plt.bar(np.arange(len(måneder)) + width * x_offset, data_per_month, width=width, color=colors[i-1], label=label_text)

    plt.xlabel('Måned')
    plt.ylabel(ylabel)
    plt.title(title)
    plt.xticks(np.arange(len(måneder)), måneder)
    plt.legend()
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()

#   Setter inn månedlige verdier for tre grafer
plot_data(datasets_energi, 'Energiproduksjon i KWh', 'Energiproduksjon fordelt på måneder')             #Energiproduksjon i søylegraf
plot_data(datasets_innstråling, 'Solinnstråling (gjennomsnitt)', 'Solinnstråling fordelt på måneder')   #Solstråling i linjegraf
plot_data(datasets_virkningsgrad, 'Virkningsgrad (gjennomsnitt)', 'Virkningsgrad fordelt på måneder')   #Virkningsgrad i linjegraf



np.save('Lyngdal_Solenergi.npy', energi_L)
np.save('Harstad_Solenergi.npy', energi_H)







































# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt

# A = 10 # m**2
# skip_last_lines = 10
# def f_solinnstråling_import(filnavn):
#     data = pd.read_csv(filnavn, delimiter=',', decimal='.', header=6)
#     data = data.head(-skip_last_lines)
    
#     tvec = pd.to_datetime(data.iloc[:,0], format='%Y%m%d:%H%M').to_numpy()
#     svec = data.iloc[:,1].to_numpy()
#     Tuvec =  data.iloc[:,2] 
#     virkningsgrad = np.where((Tuvec+20) > 25, 0.20 - 0.003 * ((Tuvec+20) - 25), np.where((Tuvec+20) < 25, 0.20 + 0.003 * (25 - (Tuvec+20)), 0.20))
#     svec = svec.astype(float)
#     energi = virkningsgrad * svec * np.array(A)
#     return tvec, svec, Tuvec, virkningsgrad, energi

# tvec_H, svec_H, Tuvec_H, virkningsgrad_H, energi_H= f_solinnstråling_import('C:\\Users\\truls\\Downloads\\Harstad.sol.csv')
# tvec_L, svec_L, Tuvec_L, virkningsgrad_L, energi_H = f_solinnstråling_import('C:\\Users\\truls\\Downloads\\Lyngdal.sol.csv')




# def calculate_monthly_energy(tvec, svec, virkningsgrad, A=10):
#     tvec_datetime = pd.to_datetime(tvec)

#     månedlig_energi = pd.DataFrame({'Energi': virkningsgrad * svec * np.array(A) / 1000}, index=tvec_datetime).resample('M').sum()
#     månedlig_energi = månedlig_energi['Energi'].values.tolist()
#     månedlig_virkningsgrad = pd.DataFrame({'Virkningsgrad': virkningsgrad}, index=tvec_datetime).resample('M').mean()
#     månedlig_virkningsgrad = månedlig_virkningsgrad['Virkningsgrad'].values.tolist()
#     månedlig_innstråling = pd.DataFrame({'Innstråling': svec}, index=tvec_datetime).resample('M').mean()
#     månedlig_innstråling = månedlig_innstråling['Innstråling'].values.tolist()
    
#     return månedlig_energi, månedlig_virkningsgrad, månedlig_innstråling

# månedlig_energi_H, månedlig_virkningsgrad_H, månedlig_innstråling_H = calculate_monthly_energy(tvec_H, svec_H, virkningsgrad_H)
# månedlig_energi_L, månedlig_virkningsgrad_L, månedlig_innstråling_L = calculate_monthly_energy(tvec_L, svec_L, virkningsgrad_L)

# print(sum(månedlig_energi_H))


# måneder = ['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Des']
# datasets_virkningsgrad = [månedlig_virkningsgrad_H, månedlig_virkningsgrad_L]
# datasets_innstråling = [månedlig_innstråling_H, månedlig_innstråling_L]
# datasets_energi = [månedlig_energi_H, månedlig_energi_L]
# colors = ['skyblue', 'salmon']
# width = 0.35
# x = np.arange(len(måneder))


# def plot_data(data, ylabel, title):
#     plt.figure(figsize=(12, 6))
#     for i, dataset in enumerate(data, start=1):
#         data_per_month = [np.sum(np.array_split(dataset, 12)[j]) for j in range(12)]
#         label_text = 'Harstad' if i == 1 else 'Lyngdal' 
#         plt.bar(x + width * (i - 1), data_per_month, width=width, color=colors[i-1], label=label_text)

#     plt.xlabel('Måned')
#     plt.ylabel(ylabel)
#     plt.title(title)
#     plt.xticks(x + width / 2, måneder)
#     plt.legend()
#     plt.grid(axis='y', linestyle='--', alpha=0.7)
#     plt.tight_layout()
#     plt.show()

# plot_data(datasets_energi, 'Energiproduksjon i KWh', 'Energiproduksjon fordelt på måneder')
# plot_data(datasets_innstråling, 'Solinnstråling (gjennomsnitt)', 'Solinnstråling fordelt på måneder')
# plot_data(datasets_virkningsgrad, 'Virkningsgrad (gjennomsnitt)', 'Virkningsgrad fordelt på måneder')













# A = 10 #m**2
# tvecH_datetime = pd.to_datetime(tvec_H)
# tvecL_datetime = pd.to_datetime(tvec_L)


# #månedlig energiproduksjon i KWH
# månedlig_energi_H = pd.DataFrame({'Energi': virkningsgrad_H*svec_H*np.array(A)/np.array(1000)}, index=tvecH_datetime).resample('M').sum()
# månedlig_energi_L = pd.DataFrame({'Energi': virkningsgrad_L*svec_L*np.array(A)/np.array(1000)}, index=tvecL_datetime).resample('M').sum()
# print(månedlig_energi_H)
# månedlig_energi_H = månedlig_energi_H['Energi'].values.tolist()
# månedlig_energi_L = månedlig_energi_L['Energi'].values.tolist()

# #månedlig virkningsgrad
# månedlig_virkningsgrad_H = pd.DataFrame({'Virkningsgrad': virkningsgrad_H}, index=tvecH_datetime).resample('M').mean()
# månedlig_virkningsgrad_L = pd.DataFrame({'Virkningsgrad': virkningsgrad_L}, index=tvecL_datetime).resample('M').mean()
# månedlig_virkningsgrad_H = månedlig_virkningsgrad_H['Virkningsgrad'].values.tolist()
# månedlig_virkningsgrad_L = månedlig_virkningsgrad_L['Virkningsgrad'].values.tolist()

# #månedlig innstråling i W/m**2
# månedlig_innstråling_H = pd.DataFrame({'Innstråling': svec_H}, index=tvecH_datetime).resample('M').mean()
# månedlig_innstråling_L = pd.DataFrame({'Innstråling': svec_L}, index=tvecL_datetime).resample('M').mean()
# månedlig_innstråling_H = månedlig_innstråling_H['Innstråling'].values.tolist()
# månedlig_innstråling_L = månedlig_innstråling_L['Innstråling'].values.tolist()





# #total energiproduksjonsgraf
# plt.figure(figsize=(12, 6))
# for i, dataset in enumerate(datasets_energi, start=1):
#     energi_per_måned = [np.sum(np.array_split(dataset, 12)[j]) for j in range(12)]
#     label_text = 'Harstad' if i == 1 else 'Lyngdal' 
#     plt.bar(x + width * (i - 1), energi_per_måned, width=width, color=colors[i-1], label=label_text)

# plt.xlabel('Måned')
# plt.ylabel('Energiproduksjon i KWh')
# plt.title('Energiproduksjon fordelt på måneder')
# plt.xticks(x + width / 2, måneder)
# plt.legend()
# plt.grid(axis='y', linestyle='--', alpha=0.7)
# plt.tight_layout()
# plt.show()


# #gjennomsnittlig innstrålingsgraf
# plt.figure(figsize=(12, 6))
# for i, dataset in enumerate(datasets_innstråling, start=1):
#     svec_per_måned = [np.sum(np.array_split(dataset, 12)[j]) for j in range(12)]
#     label_text = 'Harstad' if i == 1 else 'Lyngdal' 
#     plt.bar(x + width * (i - 1), svec_per_måned, width=width, color=colors[i-1], label=label_text)

# plt.xlabel('Måned')
# plt.ylabel('Solinnstråling (gjennomsnitt)')
# plt.title('Solinnstråling fordelt på måneder')
# plt.xticks(x + width / 2, måneder)
# plt.legend()
# plt.grid(axis='y', linestyle='--', alpha=0.7)
# plt.tight_layout()
# plt.show()


# #gjennomsnittlig virkningsgradsgraf
# plt.figure(figsize=(12, 6))
# for i, dataset in enumerate(datasets_virkningsgrad, start=1):
#     virkningsgrad_per_måned = [np.sum(np.array_split(dataset, 12)[j]) for j in range(12)]
#     label_text = 'Harstad' if i == 1 else 'Lyngdal' 
#     plt.bar(x + width * (i - 1), virkningsgrad_per_måned, width=width, color=colors[i-1], label=label_text)

# plt.xlabel('Måned')
# plt.ylabel('Virkningsgrad (gjennomsnitt)')
# plt.title('Virkningsgrad fordelt på måneder')
# plt.xticks(x + width / 2, måneder)
# plt.legend()
# plt.grid(axis='y', linestyle='--', alpha=0.7)
# plt.tight_layout()
# plt.show()
